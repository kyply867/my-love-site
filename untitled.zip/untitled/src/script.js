function sayLove() {
  alert("Aku cinta kamu, dan aku janji mau terus belajar jadi lebih baik ❤️");
}